/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connection;


import java.sql.*;


/**
 *
 * @author PC
 */
public class DBConnection {
        
   static Connection con = null;
   

    public static Connection getConnection() {

        try {
                Class.forName("com.mysql.cj.jdbc.Driver"); 
                con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/first_schema?autoReconnect=true&useSSL=FALSE","root","aguiar2259");
               
           }catch (Exception e){
               e.printStackTrace();
           }   
        return con;
    
    }
    
}
