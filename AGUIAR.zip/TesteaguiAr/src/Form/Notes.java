package Form;

import Connection.DBConnection;
import java.awt.Font;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;


public class Notes extends javax.swing.JFrame {

    private int mouseX;
    private int mouseY;
    
    public Notes() {
        initComponents();
         setTitle("My Note");
        textArea.setFont(new Font("sansserif",1,12));
        textArea.setLineWrap(false);
        textArea.setWrapStyleWord(false);
    }
     private String getnoteT(){
        String noteT = JOptionPane.showInputDialog("Please, rename the file");
        return noteT;
    }
     private boolean checkT(){
         
        String noteT = this.getTitle();
        boolean exist = false;
        
        try{
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from notes where Title = ?");
            pst.setString(1,noteT);
            ResultSet rs = pst.executeQuery();
            if (rs.next()){
                exist = true;
            }else{
                exist = false;
            }
        
        }catch(Exception e){
            e.printStackTrace();
        }  
        return exist;
    }
     
    private boolean note_is_added(){
        
        boolean is_added=false;
        
        if (checkT()==true){
            if(getnoteT().equals("My Note")){
                JOptionPane.showMessageDialog(this, "File not Saved"); 
                return false;
            }else{
                String newtitle = getnoteT();
                this.setTitle(newtitle);
                
            }      
        }
        String notaTitle = this.getTitle();
        Date date = new Date();
        java.sql.Date sqldate = new java.sql.Date(date.getTime());
        String content = this.textArea.getText();
        
        try{
            Connection con = DBConnection.getConnection();
           
            String sql = "insert into notes(Title,Data_Modification,Content) values(?,?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            
            pst.setString(1,notaTitle);
            pst.setDate(2, sqldate);
            pst.setString(3, content);
            
            int updateRowcount = pst.executeUpdate();
            if(updateRowcount > 0){
                is_added=true; 
            }else{
                is_added=false;
            }
        
        }catch(Exception e){
            e.printStackTrace();
        }
        return is_added;
    }
    private void newFile(){
        if(textArea.getText().length() < 1){
            setTitle("My Note");
            textArea.setText("");           
        }
        else {
            int confirm = JOptionPane.showConfirmDialog(this,"Woul you like to save this file?");
            if(confirm == JOptionPane.YES_OPTION){
                 if(note_is_added()==true){
                JOptionPane.showMessageDialog(this, "Saved");
               }else{
                   JOptionPane.showMessageDialog(this, "Faile to save"); 
               }                
            }else{
                this.setTitle("My Note");
                textArea.setText("");
            }
            
        }
    }
                                          

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        font = new javax.swing.JMenu();
        TNR = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        copy = new javax.swing.JMenuItem();
        save = new javax.swing.JMenuItem();
        paste = new javax.swing.JMenuItem();
        fsize = new javax.swing.JMenu();
        s14 = new javax.swing.JMenuItem();
        s16 = new javax.swing.JMenuItem();
        s18 = new javax.swing.JMenuItem();
        s22 = new javax.swing.JMenuItem();
        open = new javax.swing.JMenuItem();
        selectall = new javax.swing.JMenuItem();
        cut = new javax.swing.JMenuItem();
        New = new javax.swing.JMenuItem();
        fileChooser = new javax.swing.JFileChooser();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textArea = new javax.swing.JTextArea();

        jPopupMenu1.setComponentPopupMenu(jPopupMenu1);

        font.setText("Font");

        TNR.setText("jMenuItem1");
        font.add(TNR);

        jMenuItem1.setText("jMenuItem1");
        font.add(jMenuItem1);

        jMenuItem2.setText("jMenuItem2");
        font.add(jMenuItem2);

        jPopupMenu1.add(font);

        copy.setText("Copy");
        copy.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                copyMouseClicked(evt);
            }
        });
        jPopupMenu1.add(copy);

        save.setText("save");
        save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                saveMouseClicked(evt);
            }
        });
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        jPopupMenu1.add(save);

        paste.setText("Paste");
        paste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteActionPerformed(evt);
            }
        });
        jPopupMenu1.add(paste);

        fsize.setText("Font Size");

        s14.setText("14");
        fsize.add(s14);

        s16.setText("16");
        fsize.add(s16);

        s18.setText("18");
        fsize.add(s18);

        s22.setText("22");
        fsize.add(s22);

        jPopupMenu1.add(fsize);

        open.setText("Open");
        open.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                openMouseClicked(evt);
            }
        });
        open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openActionPerformed(evt);
            }
        });
        jPopupMenu1.add(open);

        selectall.setText("SelectAll");
        selectall.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectallActionPerformed(evt);
            }
        });
        jPopupMenu1.add(selectall);

        cut.setText("Cut");
        cut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutActionPerformed(evt);
            }
        });
        jPopupMenu1.add(cut);

        New.setText("New");
        New.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NewActionPerformed(evt);
            }
        });
        jPopupMenu1.add(New);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(30, 139, 195));
        setUndecorated(true);

        jLabel1.setBackground(new java.awt.Color(30, 139, 195));
        jLabel1.setFont(new java.awt.Font("Sitka Heading", 1, 18)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/icons8-address-book-16_1.png"))); // NOI18N
        jLabel1.setText("  My Note");
        jLabel1.setOpaque(true);
        jLabel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel1MouseDragged(evt);
            }
        });
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(30, 139, 195));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/close.png"))); // NOI18N
        jLabel2.setOpaque(true);
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        textArea.setColumns(20);
        textArea.setRows(5);
        textArea.setComponentPopupMenu(jPopupMenu1);
        jScrollPane1.setViewportView(textArea);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(jLabel2))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 405, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        this.setVisible(false);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MousePressed
        mouseX = evt.getX();
        mouseY = evt.getY();
    }//GEN-LAST:event_jLabel1MousePressed

    private void jLabel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseDragged
        this.setLocation(this.getX() + evt.getX() - mouseX, this.getY() + evt.getY() - mouseY);
    }//GEN-LAST:event_jLabel1MouseDragged

    private void copyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_copyMouseClicked
         this.textArea.copy();
    }//GEN-LAST:event_copyMouseClicked

    private void openMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_openMouseClicked
       
    }//GEN-LAST:event_openMouseClicked

    private void saveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_saveMouseClicked
        
    }//GEN-LAST:event_saveMouseClicked

    private void pasteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteActionPerformed
        this.textArea.paste();
    }//GEN-LAST:event_pasteActionPerformed

    private void selectallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectallActionPerformed
        this.textArea.selectAll();
    }//GEN-LAST:event_selectallActionPerformed

    private void cutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutActionPerformed
        this.textArea.cut();
    }//GEN-LAST:event_cutActionPerformed

    private void openActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openActionPerformed
         int returnVal = fileChooser.showOpenDialog(this);
         FileNameExtensionFilter textFilter = new FileNameExtensionFilter("Only Text Files","txt");
         fileChooser.setAcceptAllFileFilterUsed(false);
         fileChooser.addChoosableFileFilter(textFilter);
       
       if (returnVal == JFileChooser.APPROVE_OPTION){
           File myfile = fileChooser.getSelectedFile();
           this.setTitle(myfile.getName());
           try{
               this.textArea.read(new FileReader(myfile.getAbsolutePath()),null);
           }catch(IOException ex){
               System.out.println("Problem accessing" + myfile.getAbsolutePath());
           }
        }else{
           System.out.println("File access cancelled by user");
       }
    }//GEN-LAST:event_openActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
         if(note_is_added()==true){
             JOptionPane.showMessageDialog(this, "Record Inserted Successfully");
        }else{
            JOptionPane.showMessageDialog(this, "Record Insertion Faile"); 
        }
    }//GEN-LAST:event_saveActionPerformed

    private void NewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NewActionPerformed
        newFile();
    }//GEN-LAST:event_NewActionPerformed

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Notes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem New;
    private javax.swing.JMenuItem TNR;
    private javax.swing.JMenuItem copy;
    private javax.swing.JMenuItem cut;
    private javax.swing.JFileChooser fileChooser;
    private javax.swing.JMenu font;
    private javax.swing.JMenu fsize;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem open;
    private javax.swing.JMenuItem paste;
    private javax.swing.JMenuItem s14;
    private javax.swing.JMenuItem s16;
    private javax.swing.JMenuItem s18;
    private javax.swing.JMenuItem s22;
    private javax.swing.JMenuItem save;
    private javax.swing.JMenuItem selectall;
    private javax.swing.JTextArea textArea;
    // End of variables declaration//GEN-END:variables
}
