
package Form;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionListener;


public class notePanel extends javax.swing.JPanel {

    Notes nota = new Notes();
    public notePanel() {
        initComponents();
    }

   public void setColor(ActionListener event){
       
   }

   
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        takenota = new rojerusan.RSMaterialButtonCircle();

        setBackground(new java.awt.Color(255, 255, 255));

        takenota.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                takenotaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(803, Short.MAX_VALUE)
                .addComponent(takenota, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(519, Short.MAX_VALUE)
                .addComponent(takenota, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void takenotaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_takenotaActionPerformed
        nota.setVisible(true);
    }//GEN-LAST:event_takenotaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojerusan.RSMaterialButtonCircle takenota;
    // End of variables declaration//GEN-END:variables
}
