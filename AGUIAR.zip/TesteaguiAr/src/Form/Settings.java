
package Form;

import java.awt.event.ActionListener;

public class Settings extends javax.swing.JPanel {

    
    public Settings() {
        initComponents();
    }
    
    public void set_blue(ActionListener event){  
        setBlue.addActionListener(event);
     }
     public void set_green(ActionListener event){ 
         setGreen.addActionListener(event);
     }
      public void set_red(ActionListener event){
          setRed.addActionListener(event);
     }
       public void set_rose(ActionListener event){  
           setRose.addActionListener(event);
     }
        public void set_yelow(ActionListener event){ 
            setYelow.addActionListener(event);
     }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        setBlue = new rojerusan.RSMaterialButtonCircle();
        setRed = new rojerusan.RSMaterialButtonCircle();
        setGreen = new rojerusan.RSMaterialButtonCircle();
        setRose = new rojerusan.RSMaterialButtonCircle();
        setYelow = new rojerusan.RSMaterialButtonCircle();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Change Background Color:");
        add(jLabel1);
        jLabel1.setBounds(10, 11, 250, 37);
        add(setBlue);
        setBlue.setBounds(20, 60, 46, 47);

        setRed.setBackground(new java.awt.Color(255, 102, 102));
        add(setRed);
        setRed.setBounds(70, 60, 44, 47);

        setGreen.setBackground(new java.awt.Color(102, 204, 153));
        add(setGreen);
        setGreen.setBounds(120, 60, 47, 47);

        setRose.setBackground(new java.awt.Color(231, 109, 137));
        add(setRose);
        setRose.setBounds(170, 60, 47, 47);

        setYelow.setBackground(new java.awt.Color(241, 214, 147));
        add(setYelow);
        setYelow.setBounds(220, 60, 46, 47);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private rojerusan.RSMaterialButtonCircle setBlue;
    private rojerusan.RSMaterialButtonCircle setGreen;
    private rojerusan.RSMaterialButtonCircle setRed;
    private rojerusan.RSMaterialButtonCircle setRose;
    private rojerusan.RSMaterialButtonCircle setYelow;
    // End of variables declaration//GEN-END:variables
}
