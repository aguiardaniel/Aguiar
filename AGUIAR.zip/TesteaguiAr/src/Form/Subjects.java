
package Form;

import Componente.CardSub;
import Componente.SubDescription;
import Connection.DBConnection;
import Model.Model_sub;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import swing.WrapLayout;
import swing.ScrollBar;


public class Subjects extends javax.swing.JPanel {

    ImageIcon image = new ImageIcon(getClass().getResource("/nIcon/flag.png"));
    private CardSub cardSub = new CardSub();
    private SubjectPanel subPanel = new SubjectPanel();
    private SubDescription subDes = new SubDescription();
    
    
    
    
    public Subjects() {
        initComponents();
        init();
    }
    private void init(){ 
        panel.setLayout(new WrapLayout(WrapLayout.LEADING));
        createCard();
    }
   
    public void addinternalCS(String subName,  String link){  
        CardSub cs = new CardSub();
        cs.getData(subName,  link);
        panel.add(cs);
        panel.revalidate();
        panel.repaint();
    }
    
    private void createCard(){
    
        try{
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from schedule");
            while(rs.next()){
                String dia = rs.getString("dia");
                String tempo = rs.getString("time");
                String disciplina = rs.getString("subject");
                String linkcurs = rs.getString("link");
                String description = dia + " " + tempo;
                addinternalCS(disciplina, linkcurs);
            }                      
        }catch(Exception e){
            e.printStackTrace();
        } 
    } 
    public SubjectPanel createSubPanel(){
        subDes = cardSub.setData();
        subPanel.setData(subDes.getName(),subDes.getLink());   
        return subPanel;
    }
    
  
            
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();

        setBackground(new java.awt.Color(255, 255, 255));

        panel.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 840, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 521, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 523, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables
}
