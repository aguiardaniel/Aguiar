
package Model;

public class SubjDetails {
    private String name;
    private String day;
    private String time;
    private String link;

    public SubjDetails(String name, String day, String time, String link) {
        this.name = name;
        this.day = day;
        this.time = time;
        this.link = link;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
    
    public void update(String name, String day, String time, String link) {
        this.name = name;
        this.day = day;
        this.time = time;
        this.link = link;
    }

    @Override
    public String toString() {
        return "SubjDetails{" + "name=" + name + ", day=" + day + ", time=" + time + ", link=" + link + '}';
    }

    public String setName() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    

}
