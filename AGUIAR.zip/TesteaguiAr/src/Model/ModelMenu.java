
package Model;

import javax.swing.Icon;


public class ModelMenu {  
    
    Icon icon;
    String meuNome;
    String submenu[];

    public ModelMenu(Icon icon, String meuNome, String... submenu) {        
        this.icon = icon;
        this.meuNome = meuNome;
        this.submenu = submenu;
    }
    
    public Icon getIcon() {
        return icon;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }

    public String getMeuNome() {
        return meuNome;
    }

    public void setMeuNome(String meuNome) {
        this.meuNome = meuNome;
        
    }

    public String[] getSubmenu() {
        return submenu;
    }

    public void setSubmenu(String[] submenu) {
        this.submenu = submenu;
    }
   
           


}
