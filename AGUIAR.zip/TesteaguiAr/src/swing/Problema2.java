
package swing;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
 
import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
  
 
public class Problema2 extends JFrame{
 
    private static final long serialVersionUID = 1L;
    
    JMenuBar meniu;
    JMenu figura;
    JMenuItem cerc;
    JMenuItem dreptunghi;
    JMenu culoare;
    JMenuItem negru;
    JMenuItem rosu;
    JMenu mod;
    JMenuItem plin;
    JMenuItem gol;
    
    enum Tip {CERC, DREPTUNGHI};
    enum Culoare {NEGRU, ROSU};
    
    static Tip t;
    static Culoare c;
    static boolean m;
    
    Suprafata sg;
    
    
    public Problema2() {
        super("Desenare figuri");
        setLayout(new FlowLayout(FlowLayout.CENTER));
        setSize(300, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        meniu=new JMenuBar();
        figura=new JMenu("Figura");
        culoare=new JMenu("Culoare");
        mod=new JMenu("Mod");
        
        cerc = new JMenuItem(new AbstractAction("Cerc") {
 
            private static final long serialVersionUID = 1L;
 
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                t=Tip.CERC;
            }
        });
        dreptunghi = new JMenuItem(new AbstractAction("Dreptunghi") {
            
            private static final long serialVersionUID = 1L;
 
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                t=Tip.DREPTUNGHI;
            }
        });
        rosu=new JMenuItem(new AbstractAction("Rosu") {
 
            private static final long serialVersionUID = 1L;
 
            @Override
            public void actionPerformed(ActionEvent e) {
                c=Culoare.ROSU;
                
            }
        });
        negru=new JMenuItem(new AbstractAction("Negru") {
            
            private static final long serialVersionUID = 1L;
 
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                c=Culoare.NEGRU;
            }
        });
        plin=new JMenuItem(new AbstractAction("Plin") {
 
            private static final long serialVersionUID = 1L;
 
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                m=true;
            }
        });
        gol=new JMenuItem(new AbstractAction("Gol") {
 
            private static final long serialVersionUID = 1L;
 
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                m=false;
            }
        });
        
        figura.add(cerc);
        figura.add(dreptunghi);
        meniu.add(figura);
        culoare.add(negru);
        culoare.add(rosu);
        meniu.add(culoare);
        mod.add(plin);
        mod.add(gol);
        meniu.add(mod);
        
        setJMenuBar(meniu);
        
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if(sg!=null) {
                    remove(sg);
                }
                sg=new Suprafata();
                add(sg);
                repaint();
                validate();
            }
        });
        
    }
    
    class Suprafata extends JPanel {
 
        private static final long serialVersionUID = 1L;
        
        
 
        @Override
        protected void paintComponent(Graphics g) {
            // TODO Auto-generated method stub
            super.paintComponent(g);
            
            int poz_x, poz_y, x=150,y=150;
            Dimension size = getSize();
            poz_x=(size.height-x)/2;
            poz_y=(size.width-y)/2;
            
            if(c==Culoare.NEGRU)
                g.setColor(Color.BLACK);
            else if(c==Culoare.ROSU)
                g.setColor(Color.RED);
            
            if(t==Tip.CERC) {
                if(m==true)
                    g.fillOval(poz_x, poz_y, x, y);
                else
                    g.drawOval(poz_x, poz_y, x, y);
            }
            
            if(t==Tip.DREPTUNGHI) {
                if(m==true)
                    g.fillRect(poz_x, poz_y, x, y);
                else
                    g.drawRect(poz_x, poz_y, x, y);
            }
            
        }
        
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(200,200);
        }
    }
    
    
    public static void main(String[] args) {
        Problema2 gui = new Problema2();
        gui.setVisible(true);
        gui.setLocationRelativeTo(null);
    }
}
    

