
package swing;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.*;

public class textDraw {
    JButton clear,color;
    DrawArea drawarea;
    ActionListener acListener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
           if(e.getSource() == clear){
               drawarea.clear();
           }else if(e.getSource() == color){
               drawarea.Color();
           }
        }
    };
    
    
    
    public static void main(String[] args){
        new textDraw().show();
    }
    
    public void show(){
        
        JFrame frame = new JFrame("text Draw");
        Container cont = frame.getContentPane();
        cont.setLayout(new BorderLayout());
        drawarea = new DrawArea();
        
        cont.add(drawarea, BorderLayout.CENTER);
        JPanel controls = new JPanel();
        clear = new JButton("Clear");
        clear.addActionListener(acListener);
        color = new JButton("Color");
        color.addActionListener(acListener);
        
        controls.add(clear);
        controls.add(color);
        
        cont.add(controls, BorderLayout.NORTH);
        frame.setSize(600,600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
}
