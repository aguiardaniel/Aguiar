
package event;
import java.awt.*;

public interface EventMenu {
    public boolean menuPressed(Component com, boolean open);   
}
