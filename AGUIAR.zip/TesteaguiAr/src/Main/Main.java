package Main;

import Componente.About;
import Componente.Subjects.CardSub;
import Componente.Header;
import Componente.Menu;
import Componente.Calculator.CalculatorC;
import Componente.Calendar.Calendar;
import Componente.Schedule.Schedule;
import Form.MainForm;
import Componente.Settings.Settings;
import Componente.Subjects.Subjects;
import Componente.Whiteboard.WhiteBoardPanel;
import Componente.Notes.notePanel;
import event.EventMenuSelected;
import event.EventShowPopupMenu;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import net.miginfocom.swing.MigLayout;
import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.TimingTarget;
import org.jdesktop.animation.timing.TimingTargetAdapter;
import swing.MenuItem;
import swing.PopupMenu;


public class Main extends javax.swing.JFrame {
    
    private MigLayout layout;
    private Menu menu;
    private Header header;
    private MainForm main;
    private Animator animator;
    private Schedule schedule = new Schedule();
    private Settings settings = new Settings();
    private notePanel notepanel = new notePanel();
    private CalculatorC calculator = new CalculatorC();
    private About about = new About();
    
    
    public Main() {
        initComponents();
         
        init();
        
    }
    
    
    private void init(){
        
        layout = new MigLayout("fill","0[]0[100%, fill]0","0[fill, top]0");
        bg.setLayout(layout);
        menu = new Menu();
       
        
        menu.addEvent(new EventMenuSelected(){
            public void menuSelected(int menuIndex, int subMenuIndex){
                System.out.println("Menu Index -> : " + menuIndex + "Submenu Index -> " + subMenuIndex);
                if (menuIndex == 0){
                    main.showForm(schedule);
                }else if(menuIndex == 1){
                    main.showForm( new Subjects());    
                }else if(menuIndex == 2 && subMenuIndex == 0){
                      calculator.setVisible(true);
                }else if(menuIndex == 2 && subMenuIndex == 1){
                    main.showForm(new notePanel());                     
                }else if(menuIndex == 2 && subMenuIndex == 2){
                    main.showForm(new WhiteBoardPanel());
                }else if(menuIndex == 3){
                    main.showForm(new Calendar());
                }else if(menuIndex == 4){
                    main.showForm(settings);
                }else if(menuIndex == 5){
                    main.showForm(about);
                }
            }
        });
        
        
        
       
        
        menu.addEventShowPopup(new EventShowPopupMenu(){
            @Override
            public void showPopup(Component com) {
                 MenuItem item = (MenuItem) com;
                PopupMenu popup = new PopupMenu(Main.this, item.getIndex(), item.getEventSelected(), item.getMenu().getSubmenu());
                int x = Main.this.getX() + 52;
                int y = Main.this.getY() + com.getY() + 86;
                popup.setLocation(x, y);
                popup.setVisible(true); //To change body of generated methods, choose Tools | Templates.
            }
        });
        menu.initMenuItem();
        header = new Header();
        main = new MainForm();
        bg.add(menu, "w 230!, spany 2");
        bg.add(header, "h 50!, wrap");
        bg.add(main, "w 100%, h 100%");
        TimingTarget target = new TimingTargetAdapter() {
            @Override
            public void timingEvent(float fraction) {
                double width;
                if (menu.isShowMenu()) {
                    width = 60 + (170 * (1f - fraction));
                } else {
                    width = 60 + (170 * fraction);
                }
                layout.setComponentConstraints(menu, "w " + width + "!, spany2");
                menu.revalidate();
            }
            @Override
            public void end() {
                menu.setShowMenu(!menu.isShowMenu());
                menu.setEnableMenu(true);
            }

            
        };
        animator = new Animator(500, target);
        animator.setResolution(0);
        animator.setDeceleration(0.5f);
        animator.setAcceleration(0.5f);
        animator.start();
        
        header.addMenuEvent(new ActionListener() {
           @Override
            public void actionPerformed(ActionEvent ae) {
                if (!animator.isRunning()) {
                    animator.start();
                    
                }
                menu.setEnableMenu(false);
                if (menu.isShowMenu()) {
                    menu.hideallMenu();
                }
            }
        }); 
        
         main.showForm(new Schedule());
         
        
        
        
       
        
        settings.set_green(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Color first = new Color(102, 204, 153);
               Color second = new Color(46, 204, 113);     
               header.setColor(second);
               menu.setColor( second);
               schedule.setColor(second);
            }
        } );
        
        settings.set_yelow(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Color first = new Color(255, 236, 139);
               Color second = new Color(241, 214, 147);    
               header.setColor(second);
               menu.setColor( second);
               schedule.setColor(second);
            }
        } );
        
        settings.set_blue(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Color first = new Color(0, 181, 204 );
               Color second = new Color(30, 139, 195);    
               header.setColor(second);
               menu.setColor( second);
               schedule.setColor(second);
            }
        } );
        
        settings.set_rose(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Color first = new Color(190, 86, 131);
               Color second = new Color(110, 48, 75);    
               header.setColor(second);
               menu.setColor(second);
               schedule.setColor(second);
            }
        } );
        settings.set_cian(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Color first = new Color(65, 147, 169);
               Color second = new Color(0,105,146);    
               header.setColor(second);
               menu.setColor( second);
               schedule.setColor(second);
            }
        } );
        
        settings.set_red(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Color first = new Color(231, 109, 137);
               Color second = new Color(210, 77, 87);    
               header.setColor(second);
               menu.setColor( second);
               schedule.setColor(second);
            }
        } );
     
    }
    
    
    
    
    
   
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JLayeredPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setOpaque(true);

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 920, Short.MAX_VALUE)
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 645, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLayeredPane bg;
    // End of variables declaration//GEN-END:variables
}
