
package Componente;

public class SubDescription {
    
    private String name;
    private String time;
    private String link;

    public SubDescription(String name, String time, String link) {
        this.name = name;
        this.time = time;
        this.link = link;
    }

    public SubDescription() {
    }
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
    
    
    
}
