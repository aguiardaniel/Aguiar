
package Componente.Schedule;

import Connection.DBConnection;
import Componente.Subjects.Subjects;
import Model.SubjDetails;
import java.awt.Color;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;



public class Schedule extends javax.swing.JPanel {
    
    private Subjects subjest = new Subjects();
       
    public Schedule() {
        initComponents();
        setScheduleTotable();          
        setOpaque(false);
       
    }
    
    
   
    
    private void printlist(List <SubjDetails> listSubject){
        for(SubjDetails sub: listSubject){
            System.out.println(sub);
        }
    }
    
    private boolean schedule_is_ADD(){
        
        boolean isadded = false;
        
        String s_name = subject_name.getText(); 
        if(subject_name.getText().equals("") || subject_name.getText().equals("Subject")
                ||subject_name.getText().equals("")|| getLink.getText().equals("") ||
                getLink.getText().equals(" ")||getLink.getText().equals("Link")) {
            JOptionPane.showMessageDialog(this,"Please ,compllete all the statements!");
            
        }else{
            if(checkDuplicate_sub()==true){             
                s_name = getsubj_T();
            }
            String day =(String)daysbox.getSelectedItem();
            String link = getLink.getText();
            String getTime =(String)hora.getSelectedItem()+" : "+(String)minut.getSelectedItem()+" -> "+(String)hora1.getSelectedItem()+":"+(String)minut1.getSelectedItem();
            
            try{
                
                Connection con = DBConnection.getConnection();
                PreparedStatement pst = con.prepareStatement( "Insert into schedule(dia,time,subject,link) values(?,?,?,?)");
                pst.setString(1,day);
                pst.setString(2,getTime);
                pst.setString(3,s_name);
                pst.setString(4,link);
              
                int rowCount = pst.executeUpdate();
                
                if(rowCount > 0){
                     isadded = true;                   
                }else{
                    isadded = false;
                }
                subject_name.setText("");
                getTime="";
                getLink.setText("");
            }
            catch(Exception e){
               e.printStackTrace();
            }
        }
        return isadded;  
    }
    
    private String getsubj_T(){
        String noteT = JOptionPane.showInputDialog("File already exists, please, rename the file");
        return noteT;
    }
    
     private void setScheduleTotable(){
    
        try{
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from schedule");
            while(rs.next()){
                String dia = rs.getString("dia");
                String tempo = rs.getString("time");
                String disciplina = rs.getString("subject");
                String linkcurs = rs.getString("link");
                
                Object obj[] = {dia,tempo,disciplina,linkcurs};
                DefaultTableModel tbmodel =  (DefaultTableModel) scheduleTable.getModel();
                tbmodel.addRow(obj);
            }                      
        }catch(Exception e){
            e.printStackTrace();
        } 
    }
     
     private void claerSchedule(){
     
         DefaultTableModel model = (DefaultTableModel) scheduleTable.getModel();
         model.setRowCount(0);
    }
     
    private boolean checkDuplicate_sub(){
        
        String s_name = subject_name.getText();
         boolean exist = false;      
        try{
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from schedule where subject=?");
            pst.setString(1, s_name);
            ResultSet rs = pst.executeQuery();
             if (rs.next()){
                exist = true;
            }else{
                exist = false;
            }                      
        }catch(Exception e ){
            e.printStackTrace();
        }
        return exist;
    }
    
    private boolean update(){
    
         String s_name = subject_name.getText();
         String day =(String)daysbox.getSelectedItem();
         String link = getLink.getText();
         String getTime =(String)hora.getSelectedItem()+" : "+(String)minut.getSelectedItem()+" -> "+(String)hora1.getSelectedItem()+":"+(String)minut1.getSelectedItem();
         boolean isupdate = false;      
        try{
            Connection con = DBConnection.getConnection();
            String sql = "update `schedule` set dia = ? ,time = ? ,subject = ? ,link = ?";
            PreparedStatement pst = con.prepareStatement(sql); 
            pst.setString(1,day);
            pst.setString(2,getTime);
            pst.setString(3,s_name);
            pst.setString(4,link);
            
            int rowcount = pst.executeUpdate();
            
            if (rowcount > 0){
                isupdate = true;
            }else{
                isupdate = false;
            }
        }catch(Exception e ){
            e.printStackTrace();
        }
        return isupdate;    
    }
    
    private boolean deleteDate(){
        
        String s_name = subject_name.getText();
         boolean isdelet = false;      
        try{
            Connection con = DBConnection.getConnection();
            String sql = "delete from schedule where subject = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, s_name);
                       
           int rowcount = pst.executeUpdate();
             if (rowcount > 0){
                isdelet = true;
            }else{
                isdelet = false;
            }                      
        }catch(Exception e ){
            e.printStackTrace();
        }
        return isdelet;    
        
    
    }
    public void setColor(Color color){
        this.add.setBackground(color);
        this.update.setBackground(color);
        this.delete.setBackground(color);
        this.conect.setBackground(color);
        this.hora.setBackground(color);
        this.hora.setForeground(new Color(255,255,255));
        this.hora1.setBackground(color);
        this.hora1.setForeground(new Color(255,255,255));
        this.minut.setBackground(color);
        this.minut.setForeground(new Color(255,255,255));
        this.minut1.setBackground(color);
        this.minut1.setForeground(new Color(255,255,255));
        this.daysbox.setBackground(color);
        this.daysbox.setForeground(new Color(255,255,255));
        this.scheduleTable.setColorBackgoundHead(color);
        this.scheduleTable.setColorFilasForeground1(new Color(0,0,0));
        this.scheduleTable.setColorFilasForeground2(color);
        this.scheduleTable.setColorSelBackgound(color);
        
    }
    
   
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        scheduleTable = new rojerusan.RSTableMetro();
        jLabel1 = new javax.swing.JLabel();
        subject_name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        getLink = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        daysbox = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        hora1 = new javax.swing.JComboBox<>();
        hora = new javax.swing.JComboBox<>();
        minut1 = new javax.swing.JComboBox<>();
        minut = new javax.swing.JComboBox<>();
        delete = new rojerusan.RSMaterialButtonRectangle();
        add = new rojerusan.RSMaterialButtonRectangle();
        update = new rojerusan.RSMaterialButtonRectangle();
        conect = new rojerusan.RSMaterialButtonRectangle();
        jLabel7 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(null);

        scheduleTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Day", "Time", "Subjects", "Link"
            }
        ));
        scheduleTable.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        scheduleTable.setFuenteFilas(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        scheduleTable.setFuenteFilasSelect(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        scheduleTable.setFuenteHead(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        scheduleTable.setIntercellSpacing(new java.awt.Dimension(0, 0));
        scheduleTable.setRowHeight(35);
        scheduleTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                scheduleTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(scheduleTable);

        add(jScrollPane1);
        jScrollPane1.setBounds(0, 0, 452, 536);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/icons8-flying-mortarboard-30.png"))); // NOI18N
        jLabel1.setText("Subject:");
        add(jLabel1);
        jLabel1.setBounds(590, 20, 83, 26);

        subject_name.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        subject_name.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        subject_name.setText(" Subject");
        subject_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                subject_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                subject_nameFocusLost(evt);
            }
        });
        subject_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subject_nameActionPerformed(evt);
            }
        });
        add(subject_name);
        subject_name.setBounds(500, 70, 269, 31);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/link.png"))); // NOI18N
        jLabel2.setText("Link:");
        add(jLabel2);
        jLabel2.setBounds(600, 110, 83, 32);

        getLink.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        getLink.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getLink.setText("Link");
        getLink.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getLink.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                getLinkFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                getLinkFocusLost(evt);
            }
        });
        add(getLink);
        getLink.setBounds(500, 150, 269, 34);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/day-off.png"))); // NOI18N
        jLabel3.setText("Day:");
        add(jLabel3);
        jLabel3.setBounds(600, 200, 83, 30);

        daysbox.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        daysbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" }));
        add(daysbox);
        daysbox.setBounds(502, 240, 269, 35);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/time.png"))); // NOI18N
        jLabel4.setText("Time:");
        add(jLabel4);
        jLabel4.setBounds(602, 293, 68, 26);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/icons8-alarm-on-24.png"))); // NOI18N
        jLabel5.setText("To:");
        add(jLabel5);
        jLabel5.setBounds(690, 310, 55, 31);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/icons8-alarm-on-24.png"))); // NOI18N
        jLabel6.setText("From:");
        add(jLabel6);
        jLabel6.setBounds(510, 310, 70, 31);

        hora1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21" }));
        hora1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hora1ActionPerformed(evt);
            }
        });
        add(hora1);
        hora1.setBounds(660, 360, 50, 30);

        hora.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21" }));
        add(hora);
        hora.setBounds(480, 360, 50, 30);

        minut1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));
        add(minut1);
        minut1.setBounds(720, 360, 50, 30);

        minut.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" }));
        add(minut);
        minut.setBounds(540, 360, 50, 30);

        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        add(delete);
        delete.setBounds(700, 410, 93, 44);

        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        add(add);
        add.setBounds(480, 410, 93, 44);

        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        add(update);
        update.setBounds(590, 410, 93, 44);

        conect.setText("Get Connected!");
        conect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                conectActionPerformed(evt);
            }
        });
        add(conect);
        conect.setBounds(495, 502, 272, 59);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Get Connected");
        add(jLabel7);
        jLabel7.setBounds(590, 470, 110, 30);
    }// </editor-fold>//GEN-END:initComponents

    private void subject_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subject_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_subject_nameActionPerformed

    private void hora1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hora1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hora1ActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        if (schedule_is_ADD()==true){
             JOptionPane.showMessageDialog(this,"Added succesfully.");
              claerSchedule();
              setScheduleTotable();
        }else{
             JOptionPane.showMessageDialog(this,"Subject addition failed!");
         
        }           
    }//GEN-LAST:event_addActionPerformed

    private void scheduleTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_scheduleTableMouseClicked
        int row = scheduleTable.getSelectedRow();
        TableModel tb = scheduleTable.getModel();
        subject_name.setText(tb.getValueAt(row,2).toString());
        getLink.setText(tb.getValueAt(row,3).toString());
        conect.setText(tb.getValueAt(row,3).toString());
    }//GEN-LAST:event_scheduleTableMouseClicked

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed

        if (update()==true){
             JOptionPane.showMessageDialog(this,"Updated!");
              claerSchedule();
              setScheduleTotable();   
        }else{
             JOptionPane.showMessageDialog(this,"Failed to update!");
            
        }   
    }//GEN-LAST:event_updateActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
     
        if ( deleteDate()==true){
             JOptionPane.showMessageDialog(this,"Deleted!");
              claerSchedule();
              setScheduleTotable();              
        }else{
             JOptionPane.showMessageDialog(this,"Failed to Delete!");
           
        }   
    }//GEN-LAST:event_deleteActionPerformed

    private void conectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_conectActionPerformed
        Desktop browser = Desktop.getDesktop();
        try{
            browser.browse(new URI(getLink.getText()));
            
        
        }catch(IOException err){
        
        }catch(URISyntaxException err){
            
        }
    }//GEN-LAST:event_conectActionPerformed

    private void subject_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_subject_nameFocusGained
        if(subject_name.getText().equals("Subject")){
            subject_name.setText("");
        }
    }//GEN-LAST:event_subject_nameFocusGained

    private void subject_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_subject_nameFocusLost
        if(subject_name.getText().equals("")){
            subject_name.setText("Subject");
        }
    }//GEN-LAST:event_subject_nameFocusLost

    private void getLinkFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_getLinkFocusGained
       if(getLink.getText().equals("Link")){
            getLink.setText("");
        } 
    }//GEN-LAST:event_getLinkFocusGained

    private void getLinkFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_getLinkFocusLost
        if(getLink.getText().equals("")){
            getLink.setText("Link");
        } 
    }//GEN-LAST:event_getLinkFocusLost


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojerusan.RSMaterialButtonRectangle add;
    private rojerusan.RSMaterialButtonRectangle conect;
    private javax.swing.JComboBox<String> daysbox;
    private rojerusan.RSMaterialButtonRectangle delete;
    private javax.swing.JTextField getLink;
    private javax.swing.JComboBox<String> hora;
    private javax.swing.JComboBox<String> hora1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> minut;
    private javax.swing.JComboBox<String> minut1;
    private rojerusan.RSTableMetro scheduleTable;
    private javax.swing.JTextField subject_name;
    private rojerusan.RSMaterialButtonRectangle update;
    // End of variables declaration//GEN-END:variables
}
