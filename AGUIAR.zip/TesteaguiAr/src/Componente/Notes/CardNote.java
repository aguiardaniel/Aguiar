
package Componente.Notes;

import Connection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class CardNote extends javax.swing.JPanel {

    private String title;
    private String content;
    private String data;
    
    public CardNote() {
        initComponents();
    }
    
    public void getData(String title, String content){
        this.title = title;
        this.content = content;
        this.noteName.setText(this.title);
    }
    
    private boolean deleteDate(String name){

        String n_name = name;
         boolean isdelet = false;      
        try{
            Connection con = DBConnection.getConnection();
            String sql = "delete from notes where Title = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, n_name);
                       
           int rowcount = pst.executeUpdate();
             if (rowcount > 0){
                isdelet = true;
            }else{
                isdelet = false;
            }                      
        }catch(Exception e ){
            e.printStackTrace();
        }
        return isdelet;    
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mypopup = new javax.swing.JPopupMenu();
        delet = new javax.swing.JMenuItem();
        roundPanel1 = new swing.RoundPanel();
        roundPanel2 = new swing.RoundPanel();
        buttonTitle = new swing.Button();
        noteName = new javax.swing.JLabel();

        delet.setText("Delete");
        delet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletActionPerformed(evt);
            }
        });
        mypopup.add(delet);

        setBackground(new java.awt.Color(255, 255, 255));

        roundPanel1.setBackground(new java.awt.Color(255, 249, 222));

        roundPanel2.setBackground(new java.awt.Color(255, 249, 222));

        buttonTitle.setBackground(new java.awt.Color(255, 249, 222));
        buttonTitle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/Nota.png"))); // NOI18N
        buttonTitle.setComponentPopupMenu(mypopup);
        buttonTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonTitleActionPerformed(evt);
            }
        });

        noteName.setBackground(new java.awt.Color(255, 255, 255));
        noteName.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        noteName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        noteName.setComponentPopupMenu(mypopup);
        noteName.setOpaque(true);

        javax.swing.GroupLayout roundPanel2Layout = new javax.swing.GroupLayout(roundPanel2);
        roundPanel2.setLayout(roundPanel2Layout);
        roundPanel2Layout.setHorizontalGroup(
            roundPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundPanel2Layout.createSequentialGroup()
                .addGroup(roundPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(noteName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        roundPanel2Layout.setVerticalGroup(
            roundPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundPanel2Layout.createSequentialGroup()
                .addComponent(buttonTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(noteName, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout roundPanel1Layout = new javax.swing.GroupLayout(roundPanel1);
        roundPanel1.setLayout(roundPanel1Layout);
        roundPanel1Layout.setHorizontalGroup(
            roundPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundPanel1Layout.createSequentialGroup()
                .addComponent(roundPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        roundPanel1Layout.setVerticalGroup(
            roundPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundPanel1Layout.createSequentialGroup()
                .addComponent(roundPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(roundPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(roundPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void buttonTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonTitleActionPerformed
        
        Notes nota = new Notes();
        nota.getData(this.title,this.content);
        nota.setVisible(true);
    }//GEN-LAST:event_buttonTitleActionPerformed

    private void deletActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletActionPerformed
        if ( deleteDate(this.title)==true){
             JOptionPane.showMessageDialog(this,"Deleted!");             
        }else{
             JOptionPane.showMessageDialog(this,"Failed to Delete!");
           
        }  
    }//GEN-LAST:event_deletActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private swing.Button buttonTitle;
    private javax.swing.JMenuItem delet;
    private javax.swing.JPopupMenu mypopup;
    private javax.swing.JLabel noteName;
    private swing.RoundPanel roundPanel1;
    private swing.RoundPanel roundPanel2;
    // End of variables declaration//GEN-END:variables
}
