
package Componente.Notes;

import Componente.Notes.Notes;
import Componente.Notes.CardNote;
import Componente.Subjects.CardSub;
import Connection.DBConnection;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import swing.WrapLayout;


public class notePanel extends javax.swing.JPanel {

   
    private File file;
    private String path;
    
    public notePanel() {
        initComponents();
        init();
    }

    private void init(){ 
        panel.setLayout(new WrapLayout(WrapLayout.LEADING));
        getAction();        
    }
    
    public void getAction(){ 
            removeAll();
            createCard();
            repaint();
            revalidate(); 
    }
    
    public void addinternalCN(String title,  String content){  
        CardNote cn = new CardNote();
        cn.getData(title, content);
        panel.add(cn);
        panel.revalidate();
        panel.repaint();
    }
    
    private void createCard(){
    
        try{
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from notes where folders like 'no folder' "); 
            while(rs.next()){
                String title = rs.getString("Title");
                String content = rs.getString("Content");
                String folder = rs.getString("folders");
                addinternalCN(title, content);
                //String data = rs.getString("Data_Modification");
                
            }                      
        }catch(Exception e){
            e.printStackTrace();
        } 
    }
    
    private String getFilePth(){
         filechooser.showOpenDialog(this);
         
         
         try {
            file = filechooser.getSelectedFile();
            path = file.getAbsolutePath();
            path = path.replace('\\','/');

          }catch(Exception e){
                  JOptionPane.showMessageDialog(this,e);
              }
          return path; 
    }
    
   
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mypopUP = new javax.swing.JPopupMenu();
        newNote = new javax.swing.JMenuItem();
        uploadbook = new javax.swing.JMenuItem();
        filechooser = new javax.swing.JFileChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        newNote.setText("Take a new Note");
        newNote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newNoteActionPerformed(evt);
            }
        });
        mypopUP.add(newNote);

        uploadbook.setText("Upload File");
        uploadbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadbookActionPerformed(evt);
            }
        });
        mypopUP.add(uploadbook);

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        panel.setBackground(new java.awt.Color(255, 255, 255));
        panel.setComponentPopupMenu(mypopUP);

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 893, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 546, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panel);

        jLabel1.setFont(new java.awt.Font("TypoUpright BT", 1, 48)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/Nota.png"))); // NOI18N
        jLabel1.setText("Notes");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 891, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void newNoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newNoteActionPerformed
        Notes nota = new Notes();
        nota.setVisible(true);
    }//GEN-LAST:event_newNoteActionPerformed

    private void uploadbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadbookActionPerformed
        //Desktop desktop = Desktop.getDesktop();
        try{
            File pdfFile = new File(getFilePth());
            if(pdfFile.exists()){
                if(Desktop.isDesktopSupported()){
                    Desktop.getDesktop().open(pdfFile);
                }else{
                    JOptionPane.showMessageDialog(this,"Desktop is not suported");
                }
            }else{
                JOptionPane.showMessageDialog(this,"File dosent exist!");
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }//GEN-LAST:event_uploadbookActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFileChooser filechooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu mypopUP;
    private javax.swing.JMenuItem newNote;
    private javax.swing.JPanel panel;
    private javax.swing.JMenuItem uploadbook;
    // End of variables declaration//GEN-END:variables
}
