package Componente;

import Model.ModelMenu;
import event.EventMenu;
import event.EventMenuSelected;
import event.EventShowPopupMenu;
//import event.EventShowPopupMenu;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.ImageIcon;
import net.miginfocom.swing.MigLayout;
import org.jdesktop.animation.timing.Animator;
import swing.MenuAnimation;
import swing.MenuItem;
import swing.ScrollBarCustom;



public class Menu extends javax.swing.JPanel {
    
    private final MigLayout layout;
    private EventMenuSelected event;
    private EventShowPopupMenu eventShowPopup;
    private boolean enableMenu = true;
    private boolean showMenu = true;
    
    private Color first = new Color(0, 181, 204);
    private Color second = new Color(0,112,192);
  
   // private EventShowPopupMenu eventShowPopup;
    

    
    public Menu() {
        initComponents();
        sp.getViewport().setOpaque(true);
        sp.setVerticalScrollBar(new ScrollBarCustom());
        layout = new MigLayout("wrap, fillx, insets 0", "[fill]", "[]0[]");
        panel.setLayout(layout); 
        
    }

    public void addEventShowPopup(EventShowPopupMenu eventShowPopup) {
        this.eventShowPopup = eventShowPopup;
    }
    
    
     public EventMenuSelected getEvent() {
        return event;
    }

    public void addEvent(EventMenuSelected event) {
        this.event = event;
    }

    public void setEnableMenu(boolean enableMenu) {
        this.enableMenu = enableMenu;
    }

    public void setShowMenu(boolean showMenu) {
        this.showMenu = showMenu;
    }

    public boolean isShowMenu() {
        return showMenu;
    }
    
    

    public javax.swing.JPanel getPanel() {
        return panel;
    }

    //public void addEventShowPopup(EventShowPopupMenu eventShowPopup) {
        //this.eventShowPopup = eventShowPopup;
    //}
    

    
    public void initMenuItem() {
        addMenu(new ModelMenu(new ImageIcon(getClass().getResource("/nIcon/ischedule-1.png")), "  Shedule"));
        addMenu(new ModelMenu(new ImageIcon(getClass().getResource("/nIcon/school.png")), "  Subjects"));
        addMenu(new ModelMenu(new ImageIcon(getClass().getResource("/nIcon/crossed.png")), "  Tools", "Calculator", "Notes", "WhiteBord"));
        addMenu(new ModelMenu(new ImageIcon(getClass().getResource("/nIcon/calendar.png")), "  Calendar"));
        addMenu(new ModelMenu(new ImageIcon(getClass().getResource("/nIcon/settings.png")), "  Settings"));
        addMenu(new ModelMenu(new ImageIcon(getClass().getResource("/nIcon/about-1.png")), "  About"));
        //this.setFont(new Font("Serif", Font.BOLD, 30));
    }
    
    private void addMenu(ModelMenu menu) {
        panel.add(new MenuItem(menu, getEventMenu(), event, panel.getComponentCount()), "h 40!"); 
    }
    
    

    private EventMenu getEventMenu() {
        return new EventMenu() {
            @Override
            public boolean menuPressed(Component com, boolean open) {
               if (enableMenu) {
                    if (showMenu) {
                        if (open) {
                            new MenuAnimation(layout, com).openMenu();
                        } else {
                            new MenuAnimation(layout, com).closeMenu();
                        }
                        return true;
                    } else {
                        eventShowPopup.showPopup(com);
                    }
                }
                return false;
            }
        };
    }

    public void hideallMenu() {
        for (Component com : panel.getComponents()) {
            MenuItem item = (MenuItem) com;
            if (item.isOpen()) {
                new MenuAnimation(layout, com, 500).closeMenu();
                item.setOpen(false);
            }
        }
    }
    
    public void setColor( Color second){
        
        this.panel.setBackground(second);
        this.profile1.setColor(second);
    }
    
     /*protected void paintComponent(Graphics grphcs){
  
        Graphics2D g2 = (Graphics2D) grphcs;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint gra = new GradientPaint(0, 0, first, getWidth(), 0, second);
        g2.setPaint(gra);
        g2.fillRect(0, 0, getWidth(), getHeight());
        super.paintComponent(grphcs);
       
    
    
    }*/


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sp = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();
        profile1 = new Componente.Profile();

        setBackground(new java.awt.Color(255, 246, 143));
        setPreferredSize(new java.awt.Dimension(230, 613));

        sp.setBorder(null);
        sp.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        panel.setBackground(new java.awt.Color(0, 112, 192));
        panel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 436, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 608, Short.MAX_VALUE)
        );

        sp.setViewportView(panel);

        profile1.setBackground(new java.awt.Color(0, 112, 192));
        profile1.setOpaque(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sp, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(profile1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(profile1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(sp, javax.swing.GroupLayout.DEFAULT_SIZE, 546, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel panel;
    private Componente.Profile profile1;
    private javax.swing.JScrollPane sp;
    // End of variables declaration//GEN-END:variables

   
}
