
package Componente.Subjects;

import Componente.Subjects.SubjectsP;
import Connection.DBConnection;
import Model.Model_sub;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import swing.WrapLayout;
import swing.ScrollBar;


public class Subjects extends javax.swing.JPanel {

    ImageIcon image = new ImageIcon(getClass().getResource("/nIcon/flag.png"));

    public Subjects() {
        initComponents();
        init();
        
    }
    private void init(){ 
        panel.setLayout(new WrapLayout(WrapLayout.LEADING));
        getAction();
       
    }
   
    public void addinternalCS(String subName,  String link, String time){  
        CardSub cs = new CardSub();
        cs.getData(subName, link, time); 
        panel.add(cs);
        panel.revalidate();
        panel.repaint();
    }

    private void createCard(){
    
        try{
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from schedule");
            while(rs.next()){
                String dia = rs.getString("dia");
                String tempo = rs.getString("time");
                String disciplina = rs.getString("subject");
                String linkcurs = rs.getString("link");
                //String description = dia + " " + tempo;
                addinternalCS(disciplina, linkcurs, tempo);
            }                      
        }catch(Exception e){
            e.printStackTrace();
        } 
    } 
    
    public void getAction(){ 
            removeAll();
            createCard();
            createFfromdatbaseolder();
            repaint();
            revalidate(); 
    }
    
     public void addinternalCSfromfataBase(String subName, String data){ 
    
        CardSub cs = new CardSub();
        cs.getdatatodatabase(subName, data);
        panel.add(cs);
        panel.revalidate();
        panel.repaint();
    }

     private void createFfromdatbaseolder(){
    
        try{
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from folders");
            while(rs.next()){
                String name = rs.getString("name");
                String datacreation = (String)rs.getString("dataCreation"); 
                addinternalCSfromfataBase(name,datacreation);
            }                      
        }catch(Exception e){
            e.printStackTrace();
        } 
    }
     
     private boolean checkfoldername(String foldername) {
         
        boolean exist = false;
        
        try{
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("select * from folders where name = ?");
            pst.setString(1,foldername);
            ResultSet rs = pst.executeQuery();
            if (rs.next()){
                exist = true;
            }else{
                exist = false;
            }
        
        }catch(Exception e){
            e.printStackTrace();
        }  
        return exist;
     
    }
     
    private boolean createFolder_card_(){
              
        boolean is_added=false;
        String foldername = JOptionPane.showInputDialog("Please, Tipe the file name:");
        
        if (checkfoldername(foldername)==true){
            foldername = JOptionPane.showInputDialog("Please, rename the file name:");
        }
        
        Date date = new Date();
        java.sql.Date sqldate = new java.sql.Date(date.getTime());
       
        
        try{
            Connection con = DBConnection.getConnection();
           
            String sql = "insert into folders(name,dataCreation) values(?,?)";
            PreparedStatement pst = con.prepareStatement(sql);
            
            pst.setString(1,foldername);
            pst.setDate(2, sqldate);
            
            int updateRowcount = pst.executeUpdate();

            if(updateRowcount > 0){
                is_added=true; 
            }else{
                is_added=false;
            }
        
        }catch(Exception e){
            e.printStackTrace();
        }
        return is_added;
    }
    
    
     private boolean deleteDate(){
        
        CardSub cs = new CardSub();
        String s_name = cs.getName();
         boolean isdelet = false;      
        try{
            Connection con = DBConnection.getConnection();
            String sql = "delete from folders where name = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, s_name);
                       
           int rowcount = pst.executeUpdate();
             if (rowcount > 0){
                isdelet = true;
            }else{
                isdelet = false;
            }                      
        }catch(Exception e ){
            e.printStackTrace();
        }
        return isdelet;    

    }
 
    public void showForm(Component form){
        this.removeAll();
        this.add(form);
        this.repaint();
        this.revalidate();
    }
   
   
     
   
     
     
       
  
    
 
    
    
    
  
            
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        myPopUP = new javax.swing.JPopupMenu();
        createCard = new javax.swing.JMenuItem();
        update = new javax.swing.JMenuItem();
        jScrollPane1 = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();

        myPopUP.setBackground(new java.awt.Color(255, 255, 255));
        myPopUP.setComponentPopupMenu(myPopUP);

        createCard.setBackground(new java.awt.Color(255, 255, 255));
        createCard.setText("New Folder");
        createCard.setOpaque(true);
        createCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createCardActionPerformed(evt);
            }
        });
        myPopUP.add(createCard);

        update.setBackground(new java.awt.Color(255, 255, 255));
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        myPopUP.add(update);

        setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        panel.setBackground(new java.awt.Color(255, 255, 255));
        panel.setComponentPopupMenu(myPopUP);

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 840, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 521, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void createCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createCardActionPerformed
        
        if(createFolder_card_()==true){
             JOptionPane.showMessageDialog(this, "Folder Created");
             getAction();
             
        }else{
            JOptionPane.showMessageDialog(this, "Record Insert5ion Faile"); 
        }
    }//GEN-LAST:event_createCardActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        getAction();
    }//GEN-LAST:event_updateActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem createCard;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu myPopUP;
    private javax.swing.JPanel panel;
    private javax.swing.JMenuItem update;
    // End of variables declaration//GEN-END:variables

    
}
