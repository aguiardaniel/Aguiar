
package Componente.Subjects;

import Componente.Settings.Settings;
import Connection.DBConnection;
import Form.MainForm;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.event.AncestorListener;



public class CardSub extends javax.swing.JPanel {
    
    
    
    private String link;
    private String name ;
    private String date;
    private String time;
    
    
    public CardSub() {
        initComponents(); 
        
    }   
    public void getdatatodatabase(String name, String date){
        subName.setText(name);
        this.name = name;
        this.date = date;
    }

    public String getLink() {
        return link;
    }
    
    public void getData(String subname, String link, String time){
        if(subname != "" || subname != null){
            this.name = subname;
            subName.setText(subname);
        }
        if(link != "" || link!= null){
             this.link = link;
        }if(time == "" || time == null){
            this.time = "";
        }else{
            this.time = time;
        }
        
    }

//    public CardSub(String link, String name) {
//        this.link = link;
//        this.name = name;
//    }
    
    
//    public SubjectPanel creatSubPanel(){
//        subjectpanel= new SubjectPanel(this.subName.getText(),this.link);
//        return subjectpanel;
//    }
    
    
    private boolean deleteDate(String name){

        String s_name = name;
         boolean isdelet = false;      
        try{
            Connection con = DBConnection.getConnection();
            String sql = "delete from folders where name = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, s_name);
                       
           int rowcount = pst.executeUpdate();
             if (rowcount > 0){
                isdelet = true;
            }else{
                isdelet = false;
            }                      
        }catch(Exception e ){
            e.printStackTrace();
        }
        return isdelet;    
    }
    
    //public void setAction(ActionListener event){
        //this.myButoon.addActionListener(event);
    //}
  

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popMenu = new javax.swing.JPopupMenu();
        Delete = new javax.swing.JMenuItem();
        rSMaterialButtonRectangle1 = new rojerusan.RSMaterialButtonRectangle();
        background = new swing.RoundPanel();
        subName = new javax.swing.JLabel();
        myButoon = new swing.Button();

        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        popMenu.add(Delete);

        rSMaterialButtonRectangle1.setText("rSMaterialButtonRectangle1");

        setBackground(new java.awt.Color(255, 255, 255));

        background.setBackground(new java.awt.Color(255, 249, 222));
        background.setComponentPopupMenu(popMenu);

        subName.setBackground(new java.awt.Color(255, 255, 255));
        subName.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        subName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        subName.setComponentPopupMenu(popMenu);
        subName.setOpaque(true);

        myButoon.setBackground(new java.awt.Color(255, 249, 222));
        myButoon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/flag.png"))); // NOI18N
        myButoon.setComponentPopupMenu(popMenu);
        myButoon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                myButoonMouseClicked(evt);
            }
        });
        myButoon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                myButoonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout backgroundLayout = new javax.swing.GroupLayout(background);
        background.setLayout(backgroundLayout);
        backgroundLayout.setHorizontalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addGroup(backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(subName, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(myButoon, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        backgroundLayout.setVerticalGroup(
            backgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundLayout.createSequentialGroup()
                .addComponent(myButoon, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(subName, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
         if ( deleteDate(this.name)==true){
             JOptionPane.showMessageDialog(this,"Deleted!");             
        }else{
             JOptionPane.showMessageDialog(this,"Failed to Delete!");
           
        }  
    }//GEN-LAST:event_DeleteActionPerformed

    private void myButoonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_myButoonActionPerformed
        SubjectsP  subjectp = new SubjectsP();
        subjectp.setData(this.name,this.time);
        subjectp.setVisible(true);
    }//GEN-LAST:event_myButoonActionPerformed

    private void myButoonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_myButoonMouseClicked
      
        
    }//GEN-LAST:event_myButoonMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem Delete;
    private swing.RoundPanel background;
    private swing.Button myButoon;
    private javax.swing.JPopupMenu popMenu;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle1;
    private javax.swing.JLabel subName;
    // End of variables declaration//GEN-END:variables
}
