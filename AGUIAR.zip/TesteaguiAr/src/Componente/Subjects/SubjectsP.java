
package Componente.Subjects;

import Componente.Notes.CardNote;
import Componente.Notes.Notes;
import Connection.DBConnection;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import swing.WrapLayout;

public class SubjectsP extends javax.swing.JFrame {

    private String name="SubName";
    private String time;
     private int mouseX;
    private int mouseY;
    private CardNote cd = new CardNote();
    
    
    public SubjectsP() {
        initComponents();
        init();
  
    }
    public void setData(String Sname, String Stime){
        
        if(Sname == null){
             this.name = "NO NAME";
        }else{
             this.name =Sname;
             
        }
        if(Stime == null){
            this.time ="NO TIME";
        }else{
            this.time =Stime;
           
        }   
        label_name.setText(this.name);
        label_time.setText(this.time);
    }
    
    private void init(){
        
        panel.setLayout(new WrapLayout(WrapLayout.LEADING));
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        this.setLocation(size.width/2 - this.getWidth()/2, size.height/2 - this.getWidth()/2);
        //cd.getData("TESTE","POR FAVOR FUNCIONA");
        //panel.add(cd);
        getAction();
    }
    
     public void getAction(){ 
            panel.removeAll();
            createCard();
            repaint();
            revalidate(); 
    }
     
    public void addinternalCN(String title,  String content){  
        CardNote cn = new CardNote();
        cn.getData(title, content);
        panel.add(cn);
        panel.revalidate();
        panel.repaint();
    }
     
      private void createCard(){
    
        try{
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from notes where folders like '"+this.name+"'"); 
            while(rs.next()){
                String title = rs.getString("Title");
                String content = rs.getString("Content");
                String folder = rs.getString("folders");
                //System.out.println(folder);
               //if(folder == this.name){
                addinternalCN(title, content);
                //}
                //String data = rs.getString("Data_Modification");
            }                      
        }catch(Exception e){
            e.printStackTrace();
        } 
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        myPOPup = new javax.swing.JPopupMenu();
        new_note = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        back = new swing.Button();
        jScrollPane1 = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();
        label_name = new javax.swing.JLabel();
        label_time = new javax.swing.JLabel();
        barraSuperior = new javax.swing.JLabel();

        new_note.setText("Take a new Note");
        new_note.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new_noteActionPerformed(evt);
            }
        });
        myPOPup.add(new_note);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        back.setBackground(new java.awt.Color(102, 204, 255));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/back.png"))); // NOI18N
        back.setOpaque(true);
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        panel.setBackground(new java.awt.Color(255, 255, 255));
        panel.setComponentPopupMenu(myPOPup);

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 755, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 499, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panel);

        label_name.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        label_name.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        label_name.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/icons8-school-locker-48.png"))); // NOI18N
        label_name.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        label_time.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        label_time.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        label_time.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        barraSuperior.setBackground(new java.awt.Color(102, 204, 255));
        barraSuperior.setOpaque(true);
        barraSuperior.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                barraSuperiorMouseDragged(evt);
            }
        });
        barraSuperior.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                barraSuperiorMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(barraSuperior, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(label_name, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(label_time, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(barraSuperior, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                    .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label_name, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(label_time, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 496, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 759, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 587, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_backActionPerformed

    private void new_noteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_new_noteActionPerformed
        Notes nota = new Notes();
        nota.setFolder(this.name);
        nota.setVisible(true);
    }//GEN-LAST:event_new_noteActionPerformed

    private void barraSuperiorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraSuperiorMousePressed
        mouseX = evt.getX();
        mouseY = evt.getY();
    }//GEN-LAST:event_barraSuperiorMousePressed

    private void barraSuperiorMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barraSuperiorMouseDragged
        this.setLocation(this.getX() + evt.getX() - mouseX, this.getY() + evt.getY() - mouseY);
    }//GEN-LAST:event_barraSuperiorMouseDragged

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SubjectsP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private swing.Button back;
    private javax.swing.JLabel barraSuperior;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_name;
    private javax.swing.JLabel label_time;
    private javax.swing.JPopupMenu myPOPup;
    private javax.swing.JMenuItem new_note;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables
}
