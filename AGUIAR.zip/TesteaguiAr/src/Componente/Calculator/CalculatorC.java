
package Componente.Calculator;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

public class CalculatorC extends javax.swing.JFrame {

   
    public CalculatorC() {
        initComponents();
        setTitle("Calculator");
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        this.setLocation(size.width/2 - this.getWidth()/2, size.height/2 - this.getWidth()/2);
        this.setBackground(new Color(30, 139, 195));
    }
    double num1, num2,result;
    String opr;
    private int mouseX;
    private int mouseY;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rSCalendarBeanInfo1 = new rojeru_san.componentes.RSCalendarBeanInfo();
        close = new javax.swing.JLabel();
        rSMaterialButtonRectangle2 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle3 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle4 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle5 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle6 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle7 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle8 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle9 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle10 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle11 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle12 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle13 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle14 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle15 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle16 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle17 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle18 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle19 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle20 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle21 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle22 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle23 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle24 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle25 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle26 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle27 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle28 = new rojerusan.RSMaterialButtonRectangle();
        rSMaterialButtonRectangle29 = new rojerusan.RSMaterialButtonRectangle();
        p_superior = new javax.swing.JLabel();
        text = new javax.swing.JTextField();
        rSMaterialButtonRectangle30 = new rojerusan.RSMaterialButtonRectangle();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Calculator");
        setBackground(new java.awt.Color(255, 249, 222));
        setUndecorated(true);

        close.setBackground(new java.awt.Color(30, 139, 195));
        close.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/close.png"))); // NOI18N
        close.setOpaque(true);
        close.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeMouseClicked(evt);
            }
        });

        rSMaterialButtonRectangle2.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle2.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle2.setText("log");
        rSMaterialButtonRectangle2.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle2ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle3.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle3.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle3.setText("B");
        rSMaterialButtonRectangle3.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle3ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle4.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle4.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle4.setText("R");
        rSMaterialButtonRectangle4.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle4ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle5.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle5.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle5.setText("1/x");
        rSMaterialButtonRectangle5.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle5ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle6.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle6.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle6.setText("bin");
        rSMaterialButtonRectangle6.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle6ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle7.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle7.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle7.setText("%");
        rSMaterialButtonRectangle7.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle7ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle8.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle8.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle8.setText("0");
        rSMaterialButtonRectangle8.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle8ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle9.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle9.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle9.setText("1");
        rSMaterialButtonRectangle9.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle9ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle10.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle10.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle10.setText("4");
        rSMaterialButtonRectangle10.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle10ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle11.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle11.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle11.setText("7");
        rSMaterialButtonRectangle11.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle11ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle12.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle12.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle12.setText("x^y");
        rSMaterialButtonRectangle12.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle12ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle13.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle13.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle13.setText("!");
        rSMaterialButtonRectangle13.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle13ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle14.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle14.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle14.setText(".");
        rSMaterialButtonRectangle14.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle14ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle15.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle15.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle15.setText("2");
        rSMaterialButtonRectangle15.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle15ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle16.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle16.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle16.setText("5");
        rSMaterialButtonRectangle16.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle16ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle17.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle17.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle17.setText("8");
        rSMaterialButtonRectangle17.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle17ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle18.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle18.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle18.setText("+");
        rSMaterialButtonRectangle18.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle18ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle19.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle19.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle19.setText("tan");
        rSMaterialButtonRectangle19.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle19ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle20.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle20.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle20.setText("-");
        rSMaterialButtonRectangle20.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle20ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle21.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle21.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle21.setText("/");
        rSMaterialButtonRectangle21.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle21ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle22.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle22.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle22.setText("cos");
        rSMaterialButtonRectangle22.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle22ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle23.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle23.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle23.setText("sin");
        rSMaterialButtonRectangle23.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle23ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle24.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle24.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle24.setText("exp");
        rSMaterialButtonRectangle24.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle24ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle25.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle25.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle25.setText("clr");
        rSMaterialButtonRectangle25.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle25ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle26.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle26.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle26.setText("=");
        rSMaterialButtonRectangle26.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle26ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle27.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle27.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle27.setText("3");
        rSMaterialButtonRectangle27.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle27ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle28.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle28.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle28.setText("9");
        rSMaterialButtonRectangle28.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle28ActionPerformed(evt);
            }
        });

        rSMaterialButtonRectangle29.setBackground(new java.awt.Color(102, 204, 255));
        rSMaterialButtonRectangle29.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle29.setText("6");
        rSMaterialButtonRectangle29.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle29ActionPerformed(evt);
            }
        });

        p_superior.setBackground(new java.awt.Color(30, 139, 195));
        p_superior.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_superior.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nIcon/cal.png"))); // NOI18N
        p_superior.setText("Calculator");
        p_superior.setOpaque(true);
        p_superior.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                p_superiorMouseDragged(evt);
            }
        });
        p_superior.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                p_superiorMousePressed(evt);
            }
        });

        text.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N

        rSMaterialButtonRectangle30.setBackground(new java.awt.Color(30, 139, 195));
        rSMaterialButtonRectangle30.setForeground(new java.awt.Color(0, 0, 0));
        rSMaterialButtonRectangle30.setText("*");
        rSMaterialButtonRectangle30.setFont(new java.awt.Font("Roboto Medium", 1, 18)); // NOI18N
        rSMaterialButtonRectangle30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonRectangle30ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(p_superior, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(close))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(text)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rSMaterialButtonRectangle11, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle17, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rSMaterialButtonRectangle10, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle16, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(rSMaterialButtonRectangle28, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(rSMaterialButtonRectangle21, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(rSMaterialButtonRectangle29, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(rSMaterialButtonRectangle20, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rSMaterialButtonRectangle6, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle8, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle14, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle26, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rSMaterialButtonRectangle9, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle15, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle27, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle18, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rSMaterialButtonRectangle5, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(rSMaterialButtonRectangle2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, 0)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rSMaterialButtonRectangle13, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(rSMaterialButtonRectangle12, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, 0)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rSMaterialButtonRectangle7, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(rSMaterialButtonRectangle4, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, 0)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rSMaterialButtonRectangle3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(rSMaterialButtonRectangle30, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rSMaterialButtonRectangle25, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rSMaterialButtonRectangle24, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rSMaterialButtonRectangle23, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle22, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(rSMaterialButtonRectangle19, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(close, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                    .addComponent(p_superior, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(text, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rSMaterialButtonRectangle25, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle24, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle23, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle22, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle19, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(rSMaterialButtonRectangle2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rSMaterialButtonRectangle4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rSMaterialButtonRectangle3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rSMaterialButtonRectangle5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(rSMaterialButtonRectangle7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(rSMaterialButtonRectangle30, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, 0)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rSMaterialButtonRectangle11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle17, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle28, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle21, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rSMaterialButtonRectangle10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle16, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle29, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle20, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rSMaterialButtonRectangle9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle27, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle18, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, 0)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rSMaterialButtonRectangle6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle14, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rSMaterialButtonRectangle26, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(rSMaterialButtonRectangle12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rSMaterialButtonRectangle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle2ActionPerformed
        double t = Math.log(Double.parseDouble(text.getText()));
        text.setText("");
        text.setText(text.getText() + t);
    }//GEN-LAST:event_rSMaterialButtonRectangle2ActionPerformed

    private void rSMaterialButtonRectangle3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle3ActionPerformed
        String backspace = null;
        
        if(text.getText().length() > 0){
            StringBuilder s = new StringBuilder(text.getText());
            s.deleteCharAt(text.getText().length() - 1);
            backspace = s.toString();
            text.setText(backspace);
        }
    }//GEN-LAST:event_rSMaterialButtonRectangle3ActionPerformed

    private void rSMaterialButtonRectangle4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle4ActionPerformed
        double t = Math.sqrt(Double.parseDouble(text.getText()));
        text.setText("");
        text.setText(text.getText() + t);
    }//GEN-LAST:event_rSMaterialButtonRectangle4ActionPerformed

    private void rSMaterialButtonRectangle5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle5ActionPerformed
        double t = 1/(Double.parseDouble(text.getText()));
        text.setText("");
        text.setText(text.getText() + t);
    }//GEN-LAST:event_rSMaterialButtonRectangle5ActionPerformed

    private void rSMaterialButtonRectangle6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSMaterialButtonRectangle6ActionPerformed

    private void rSMaterialButtonRectangle7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle7ActionPerformed
        num1 = Double.parseDouble(text.getText());
        text.setText("");
        opr = "%";
    }//GEN-LAST:event_rSMaterialButtonRectangle7ActionPerformed

    private void rSMaterialButtonRectangle8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle8ActionPerformed
        text.setText(text.getText() + "0");
    }//GEN-LAST:event_rSMaterialButtonRectangle8ActionPerformed

    private void rSMaterialButtonRectangle9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle9ActionPerformed
        text.setText(text.getText() + "1");
    }//GEN-LAST:event_rSMaterialButtonRectangle9ActionPerformed

    private void rSMaterialButtonRectangle10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle10ActionPerformed
        text.setText(text.getText() + "4");
    }//GEN-LAST:event_rSMaterialButtonRectangle10ActionPerformed

    private void rSMaterialButtonRectangle11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle11ActionPerformed
        text.setText(text.getText() + "7");
    }//GEN-LAST:event_rSMaterialButtonRectangle11ActionPerformed

    private void rSMaterialButtonRectangle12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle12ActionPerformed
        num1 = Double.parseDouble(text.getText());
        text.setText("");
        opr = "X^Y";
    }//GEN-LAST:event_rSMaterialButtonRectangle12ActionPerformed

    private void rSMaterialButtonRectangle13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle13ActionPerformed
        double t = Double.parseDouble(text.getText());
        double fact = 1;
        
        while(t != 0){
            fact*=t;
            t--;
        }
        text.setText("");
        text.setText(text.getText() + fact);
    }//GEN-LAST:event_rSMaterialButtonRectangle13ActionPerformed

    private void rSMaterialButtonRectangle14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle14ActionPerformed
        text.setText(text.getText() + ",");
    }//GEN-LAST:event_rSMaterialButtonRectangle14ActionPerformed

    private void rSMaterialButtonRectangle15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle15ActionPerformed
        text.setText(text.getText() + "2");
    }//GEN-LAST:event_rSMaterialButtonRectangle15ActionPerformed

    private void rSMaterialButtonRectangle16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle16ActionPerformed
        text.setText(text.getText() + "5");
    }//GEN-LAST:event_rSMaterialButtonRectangle16ActionPerformed

    private void rSMaterialButtonRectangle17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle17ActionPerformed
        text.setText(text.getText() + "8");
    }//GEN-LAST:event_rSMaterialButtonRectangle17ActionPerformed

    private void rSMaterialButtonRectangle18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle18ActionPerformed
        num1 = Double.parseDouble(text.getText());
        text.setText("");
        opr = "+";
    }//GEN-LAST:event_rSMaterialButtonRectangle18ActionPerformed

    private void rSMaterialButtonRectangle19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle19ActionPerformed
        double t = Math.tan(Double.parseDouble(text.getText()));
        text.setText("");
        text.setText(text.getText() + t);

    }//GEN-LAST:event_rSMaterialButtonRectangle19ActionPerformed

    private void rSMaterialButtonRectangle20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle20ActionPerformed
        num1 = Double.parseDouble(text.getText());
        text.setText("");
        opr = "-";
    }//GEN-LAST:event_rSMaterialButtonRectangle20ActionPerformed

    private void rSMaterialButtonRectangle21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle21ActionPerformed
        num1 = Double.parseDouble(text.getText());
        text.setText("");
        opr = "/";
    }//GEN-LAST:event_rSMaterialButtonRectangle21ActionPerformed

    private void rSMaterialButtonRectangle22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle22ActionPerformed
        double t = Math.cos(Double.parseDouble(text.getText()));
        text.setText("");
        text.setText(text.getText() + t);
    }//GEN-LAST:event_rSMaterialButtonRectangle22ActionPerformed

    private void rSMaterialButtonRectangle23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle23ActionPerformed
        double t = Math.sin(Double.parseDouble(text.getText()));
        text.setText("");
        text.setText(text.getText() + t);
    }//GEN-LAST:event_rSMaterialButtonRectangle23ActionPerformed

    private void rSMaterialButtonRectangle24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle24ActionPerformed
        double t = Math.exp(Double.parseDouble(text.getText()));
        text.setText("");
        text.setText(text.getText() + t);
    }//GEN-LAST:event_rSMaterialButtonRectangle24ActionPerformed

    private void rSMaterialButtonRectangle25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle25ActionPerformed
        text.setText("");
    }//GEN-LAST:event_rSMaterialButtonRectangle25ActionPerformed

    private void rSMaterialButtonRectangle26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle26ActionPerformed
        num2 = Double.parseDouble(text.getText());
        
        if(opr == "+"){
            result = num1 + num2;
            text.setText(Double.toString(result));
        }else if(opr == "-"){
             result = num1 - num2;
            text.setText(Double.toString(result));
        }else if (opr == "*"){
             result = num1 * num2;
            text.setText(Double.toString(result));
        }else if (opr == "/"){
             result = num1 / num2;
            text.setText(Double.toString(result));
        }else if(opr == "%"){
             result = num1 % num2;
            text.setText(Double.toString(result));
        }else if(opr == "X^Y"){
            if(num2 == 0){
                result = 1;
            }else if(num2 == 1){
                result = num1;
            }
            for (int i=1; i< num2; i++){
                result = num1 * num1;
            }
            text.setText(Double.toString(result));            
        }
    }//GEN-LAST:event_rSMaterialButtonRectangle26ActionPerformed

    private void rSMaterialButtonRectangle27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle27ActionPerformed
        text.setText(text.getText() + "3");
    }//GEN-LAST:event_rSMaterialButtonRectangle27ActionPerformed

    private void rSMaterialButtonRectangle28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle28ActionPerformed
        text.setText(text.getText() + "9");
    }//GEN-LAST:event_rSMaterialButtonRectangle28ActionPerformed

    private void rSMaterialButtonRectangle29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle29ActionPerformed
        text.setText(text.getText() + "6");
    }//GEN-LAST:event_rSMaterialButtonRectangle29ActionPerformed

    private void closeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeMouseClicked
        this.setVisible(false);
        
    }//GEN-LAST:event_closeMouseClicked

    private void p_superiorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_p_superiorMousePressed
        mouseX = evt.getX();
        mouseY = evt.getY();
    }//GEN-LAST:event_p_superiorMousePressed

    private void p_superiorMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_p_superiorMouseDragged
         this.setLocation(this.getX() + evt.getX() - mouseX, this.getY() + evt.getY() - mouseY);
    }//GEN-LAST:event_p_superiorMouseDragged

    private void rSMaterialButtonRectangle30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonRectangle30ActionPerformed
        num1 = Double.parseDouble(text.getText());
        text.setText("");
        opr = "*";
    }//GEN-LAST:event_rSMaterialButtonRectangle30ActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CalculatorC().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel close;
    private javax.swing.JLabel p_superior;
    private rojeru_san.componentes.RSCalendarBeanInfo rSCalendarBeanInfo1;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle10;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle11;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle12;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle13;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle14;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle15;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle16;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle17;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle18;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle19;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle2;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle20;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle21;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle22;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle23;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle24;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle25;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle26;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle27;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle28;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle29;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle3;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle30;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle4;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle5;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle6;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle7;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle8;
    private rojerusan.RSMaterialButtonRectangle rSMaterialButtonRectangle9;
    private javax.swing.JTextField text;
    // End of variables declaration//GEN-END:variables
}
